// Copyright (c) 2016 NoodleOfDeath <noodlebox@noodlenation.net>
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in
// all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
// THE SOFTWARE.

import CoreImage
import UIKit

import SnapKit

// MARK: - Path Concatentation Infix Operator

infix operator +/

func +/ (lhs: String, rhs: String) -> String {
    return lhs.appendingPathComponent(rhs)
}

func +/ (lhs: String?, rhs: String) -> String? {
    guard let lhs = lhs else { return nil }
    return lhs.appendingPathComponent(rhs)
}

func +/ (lhs: String, rhs: String?) -> String? {
    guard let rhs = rhs else { return nil }
    return lhs.appendingPathComponent(rhs)
}

func +/ (lhs: URL, rhs: String) -> URL {
    return lhs.appendingPathComponent(rhs)
}

func +/ (lhs: URL?, rhs: String) -> URL? {
    guard let lhs = lhs else { return nil }
    return lhs.appendingPathComponent(rhs)
}

func +/ (lhs: URL, rhs: String?) -> URL? {
    guard let rhs = rhs else { return nil }
    return lhs.appendingPathComponent(rhs)
}

// MARK: - Math Operations

func % (lhs: Double, rhs: Double) -> Double {
    return lhs.truncatingRemainder(dividingBy: rhs)
}

func % (lhs: Double, rhs: Int) -> Double {
    return lhs.truncatingRemainder(dividingBy: Double(rhs))
}

func % (lhs: Int, rhs: Double) -> Int {
    return lhs % Int(rhs)
}

// MARK: - NSRange Property Extensions
extension NSRange {
    
    /// Returns the sum of the `location` and `length` of this range.
    /// Shorthand for `NSMaxRange(self)`.
    var max: Int { return NSMaxRange(self) }
    
}

// MARK: - String Property Extensions (NSString Bridging Properties)
extension String {
    
    /// This string casted as a `NSString`.
    var ns: NSString { return self as NSString }
    
    /// The length of this string in terms of number of bytes.
    var length: Int { return ns.length }
    
    /// Shorthand for `NSMakeRange(0, length)`.
    var range: NSRange { return NSMakeRange(0, length) }
    
    /// First letter of this string; or an empty string if this string is empty.
    var firstLetter: String { return length > 0 ? substring(to: 1) : "" }
    
}

// MARK: - String Method Extensions (NSString Bridging Methods)
extension String {
    
    /// Returns a new string containing the characters of the receiver up to,
    /// but not including, the one at a given index.
    /// - parameter index: An index. The value must lie within the bounds
    /// of the receiver, or be equal to the length of the receiver.
    /// Raises an rangeException if (anIndex - 1) lies beyond the end of the
    /// receiver.
    /// - returns: A new string containing the characters of the receiver up
    /// to, but not including, the one at anIndex. If anIndex is equal to the
    /// length of the string, returns a copy of the receiver.
    func substring(to index: Int) -> String {
        return ns.substring(to: index)
    }
    
    /// Returns a new string containing the characters of the receiver up to,
    /// but not including, the one at a given index.
    /// - parameter index: An index. The value must lie within the bounds of
    /// the receiver, or be equal to the length of the receiver.
    /// Raises an rangeException if (anIndex - 1) lies beyond the end of the
    /// receiver.
    /// - returns: A new string containing the characters of the receiver from
    /// the one at anIndex to the end. If anIndex is equal to the length of the
    /// string, returns an empty string.
    func substring(from index: Int) -> String {
        return ns.substring(from: index)
    }
    
    ///
    /// - parameter range: A range. The range must not exceed the bounds of the
    /// receiver. Raises an rangeException if `(aRange.location - 1)` or
    /// `(aRange.location + aRange.length - 1)` lies beyond the end of the
    /// receiver.
    /// - returns: A string object containing the characters of the receiver
    /// that lie within `range`.
    func substring(with range: NSRange) -> String {
        return ns.substring(with: range)
    }
    
    /// Returns a new string made by appending to the receiver a given string.
    /// - parameter str: The path component to append to the receiver.
    /// - returns: A new string made by appending aString to the receiver,
    /// preceded if necessary by a path separator.
    func appendingPathComponent(_ str: String) -> String {
        return ns.appendingPathComponent(str)
    }
    
    /// Returns a new string made by appending to the receiver an extension
    /// separator followed by a given extension.
    /// - parameter ext: The extension to append to the receiver.
    /// - returns: A new string made by appending to the receiver an extension
    /// separator followed by `ext`.
    func appendingPathExtension(_ ext: String) -> String? {
        return ns.appendingPathExtension(ext)
    }
    
    /// Returns a new string in which all occurrences of a target string in a
    /// specified range of the receiver are replaced by another given string.
    /// - parameter target: The string to replace.
    /// - parameter replacement: The string with which to replace `target`.
    /// - parameter options: A mask of options to use when comparing `target`
    /// with the receiver. Pass `0` to specify no options.
    /// - parameter range: The range in the receiver in which to search
    /// for `target`.
    /// - returns: A new string in which all occurrences of `target`, matched
    /// using `options`, in `searchRange` of the receiver are replaced by
    /// `replacement`.
    func replacingOccurrences(of target: String, with replacement: String, options: NSString.CompareOptions, range: NSRange) -> String {
        return ns.replacingOccurrences(of: target, with: replacement, options: options, range: range)
    }
    
    ///
    func matches(_ searchText: String, options: (NSRegularExpression.Options, NSRegularExpression.MatchingOptions) = ([],[]), range: NSRange? = nil) -> Bool {
        return firstMatch(in: searchText, options: options, range: range) != nil
    }
    
    ///
    func firstMatch(in searchText: String, options: (NSRegularExpression.Options, NSRegularExpression.MatchingOptions) = ([],[]), range: NSRange? = nil) -> NSTextCheckingResult? {
        return (try? NSRegularExpression(pattern: self, options: options.0))?.firstMatch(in: searchText, options: options.1, range: range ?? searchText.range)
    }
    
}

// MARK: - String Font Extension
extension String {
    
    /// Attempts to return the font specified by name of the appropriate point
    /// size for this string to fit within a particular container size and
    /// constrained to a lower and upper bound point size.
    /// - parameter name: of the font.
    /// - parameter containerSize: that this string should fit inside.
    /// - parameter lowerBound: minimum allowable point size of this font.
    /// - parameter upperBound: maximum allowable point size of this font.
    /// - returns: the font specified by name of the appropriate point
    /// size for this string to fit within a particular container size and
    /// constrained to a lower and upper bound point size; `nil` if no such
    /// font exists.
    func font(named name: String,
              toFit containerSize: CGSize,
              noSmallerThan lowerBound: CGFloat = 1.0,
              noLargerThan upperBound: CGFloat = 256.0) -> UIFont? {
        let lowerBound = lowerBound > upperBound ? upperBound : lowerBound
        let mid = lowerBound + (upperBound - lowerBound) / 2
        guard let tempFont = UIFont(name: name, size: mid) else { return nil }
        let difference = containerSize.height -
            self.size(withAttributes:
                [NSAttributedStringKey.font : tempFont]).height
        if mid == lowerBound || mid == upperBound {
            return UIFont(name: name, size: difference < 0 ? mid - 1 : mid)
        }
        return difference < 0 ? font(named: name,
                                     toFit: containerSize,
                                     noSmallerThan: mid,
                                     noLargerThan: mid - 1) :
            (difference > 0 ? font(named: name,
                                   toFit: containerSize,
                                   noSmallerThan: mid,
                                   noLargerThan: mid - 1) :
                UIFont(name: name, size: mid))
    }
    
    /// Returns the system font of the appropriate point size for this string
    /// to fit within a particular container size and constrained to a lower
    /// and upper bound point size.
    /// - parameter containerSize: that this string should fit inside.
    /// - parameter lowerBound: minimum allowable point size of this font.
    /// - parameter upperBound: maximum allowable point size of this font.
    /// - returns: the system font of the appropriate point size for this string
    /// to fit within a particular container size and constrained to a lower
    /// and upper bound point size.
    func systemFont(toFit containerSize: CGSize,
                    noSmallerThan lowerBound: CGFloat = 1.0,
                    noLargerThan upperBound: CGFloat = 256.0) -> UIFont {
        let lowerBound = lowerBound > upperBound ? upperBound : lowerBound
        let mid = lowerBound + (upperBound - lowerBound) / 2
        let tempFont = UIFont.systemFont(ofSize: mid)
        let difference = containerSize.height -
            self.size(withAttributes:
                [NSAttributedStringKey.font : tempFont]).height
        if mid == lowerBound || mid == upperBound {
            return UIFont.systemFont(ofSize: difference < 0 ? mid - 1 : mid)
        }
        return difference < 0 ? systemFont(toFit: containerSize,
                                           noSmallerThan: mid,
                                           noLargerThan: mid - 1) :
            (difference > 0 ? systemFont(toFit: containerSize,
                                         noSmallerThan: mid,
                                         noLargerThan: mid - 1) :
                UIFont.systemFont(ofSize: mid))
    }
    
}

// MARK: - 

// MARK: - UIColor Extensions
extension UIColor {
    
    convenience init(_ hex: UInt, alpha: CGFloat = 1.0) {
        self.init(red: CGFloat((hex & 0xFF0000) >> 16) / 255.0,
                  green: CGFloat((hex & 0x00FF00) >> 8) / 255.0,
                  blue: CGFloat(hex & 0x0000FF) / 255.0, alpha: alpha)
    }
    
}

// MARK: - UserDefaults Subscript Extensions
extension UserDefaults {
    
    /// Shorthand for `value(forKey:)` and `set(_, forKey:)`.
    /// - parameter value: to set in user defaults.
    /// - parameter key: key of the user default value to set/retrieve.
    subscript <T>(key: String) -> T? {
        get { return value(forKey: key) as? T }
        set { set(newValue, forKey: key) }
    }
    
}

// MARK: - UIImage Property Extensions
extension UIImage {
    
    /// Width of this image.
    var width: CGFloat {
        return size.width
    }
    
    /// Height of this image.
    var height: CGFloat {
        return size.height
    }
    
}

// MARK: - UIImage Method Extensions
extension UIImage {
    
    /// Returns an copt of this image that is cropped to a given rect.
    /// - parameter rect: Rect to crop this image to.
    /// - returns: A copy of this image that is cropped to fit `rect`.
    func cropping(to rect: CGRect) -> UIImage? {
        if let image = self.cgImage?.cropping(to: rect) {
            return UIImage(cgImage: image)
        } else if let image = (self.ciImage)?.cropped(to: rect) {
            return UIImage(ciImage: image)
        }
        return nil
    }
    
    /// Returns an image that is scaled and cropped to a target size.
    /// - parameter targetSize: Size to scale and/or crop this image to.
    /// - returns: A copy of this image that is scaled and cropped to a
    /// target size.
    func scalingAndCropping(to targetSize: CGSize) -> UIImage? {
        
        let sourceImage = self
        
        var newImage: UIImage?
        
        var scaleFactor: CGFloat = 0.0
        var scaledWidth: CGFloat = targetSize.width
        var scaledHeight: CGFloat = targetSize.height
        
        var thumbnailPoint: CGPoint = CGPoint(x: 0.0, y: 0.0)
        
        if (sourceImage.size != targetSize) {
            
            let widthFactor = targetSize.width / width
            let heightFactor = targetSize.height / height
            
            if (widthFactor > heightFactor) { // Scale to fit height
                scaleFactor = widthFactor
            } else{ // Scale to fit width
                scaleFactor = heightFactor
            }
            
            scaledWidth = width * scaleFactor
            scaledHeight = height * scaleFactor
            
            // Center the image
            if (widthFactor > heightFactor) {
                thumbnailPoint.y = (targetSize.height - scaledHeight) * 0.5 // Could not find an overload for '*' that accepts the supplied arguments
            } else{
                if (widthFactor < heightFactor) {
                    thumbnailPoint.x = (targetSize.width - scaledWidth) * 0.5 // Could not find an overload for '*' that accepts the supplied arguments
                }
            }
            
        }
        
        UIGraphicsBeginImageContext(targetSize)
        
        var thumbnailRect: CGRect = CGRect.zero
        thumbnailRect.origin = thumbnailPoint
        thumbnailRect.size.width = scaledWidth // Cannot convert the expression's type '()' to type 'CGFloat'
        thumbnailRect.size.height = scaledHeight // Cannot convert the expression's type '()' to type 'CGFloat'
        
        sourceImage.draw(in: thumbnailRect)
        
        newImage = UIGraphicsGetImageFromCurrentImageContext()
        
        // pop the context to get back to the default
        UIGraphicsEndImageContext()
        
        return newImage
        
    }
    
}

// MARK: - UIView Property Extensions
extension UIView {
    
    /// x value of the origin coordinate of this view.
    var x: CGFloat { return frame.origin.x }
    
    /// y value of the origin coordinate of this view.
    var y: CGFloat { return frame.origin.y }
    
    /// Width of this view.
    var width: CGFloat { return frame.width }
    
    /// Height of this view.
    var height: CGFloat { return frame.height }
    
}

// MARK: - UIView SnapKit Extensions
extension UIView {
    
    /// Constrains the edges of this view to the edges of its superview using
    /// specified edge insets.
    /// - parameter edgeInsets: to inset the edges of this view within its
    /// superview with.
    func constrainToSuperview(edgeInsets: UIEdgeInsets = .zero) {
        guard let superview = superview else { return }
        snp.makeConstraints { (dims) in
            dims.top.equalTo(superview).offset(edgeInsets.top)
            dims.left.equalTo(superview).offset(edgeInsets.left)
            dims.bottom.equalTo(superview).offset(edgeInsets.bottom)
            dims.right.equalTo(superview).offset(edgeInsets.right)
        }
    }
    
    /// Constrains the edges of this view to the edges of its superview using a
    /// specified padding constant.
    /// - parameter padding: constant to inset the edges of this view within
    /// its superview with.
    func constrainToSuperview(padding: CGFloat) {
        constrainToSuperview(edgeInsets: UIEdgeInsets(top: padding,
                                                      left: padding,
                                                      bottom: -padding,
                                                      right: -padding))
    }
    
    /// Adds a subview and constrains its edges to the edges of this view using
    /// specified edge insets.
    /// - parameter subview: to add to this view.
    /// - parameter edgeInsets: to inset the edges of this view within its
    /// superview with.
    func addConstrainedSubview(_ subview: UIView, edgeInsets: UIEdgeInsets = .zero) {
        addSubview(subview)
        subview.constrainToSuperview(edgeInsets: edgeInsets)
    }
    
    /// Adds a subview and constrains its edges to the edges of this view using
    /// a specified padding constant.
    /// - parameter subview: to add to this view.
    /// - parameter padding: constant to inset the edges of this view within
    /// its superview with.
    func addConstrainedSubview(_ subview: UIView, padding: CGFloat) {
        addSubview(subview)
        subview.constrainToSuperview(padding: padding)
    }
    
}

// MARK: - UIViewController Property Extensions
extension UIViewController {
    
    /// Embeds this view controller as the root view controller of a new
    /// `UINavigationController` instance, and returns that instance.
    var asNavigationController: UINavigationController {
        return UINavigationController(rootViewController: self)
    }
    
}
