//
// The MIT License (MIT)
//
// Copyright © 2017 NoodleOfDeath. All rights reserved.
// NoodleOfDeath
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in
// all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
// THE SOFTWARE.

import UIKit

import SnapKit
import SwiftyFilesystem

/// Specifies the required event handler methods for an object that
/// will delegate one or more `FileExplorer` instances.
@objc(FileExplorerDelegate)
public protocol FileExplorerDelegate: class  {
    
    // MARK: - Configuration Methods
    
    /// Returns a theme to use when displaying the table view.
    /// - parameter explorer: to apply the theme to.
    /// - returns: theme to use when displaying the table view.
    @objc
    optional func theme(forFileExplorer explorer: FileExplorer) -> FileExplorer.Theme?
    
    /// Returns a set of toolbar items to display for a explorer.
    /// - parameter explorer: to provide with toolbar items.
    @objc
    optional func toolbarItems(forFileExplorer explorer: FileExplorer) -> [UIBarButtonItem]
    
    /// Returns a maximum file size to generate thumbnails for.
    /// - parameter explorer: to provide maximum thumbnail size for.
    /// - returns: maximum file size to allow for thumbnail generation.
    /// Default return value is recommended to be `4 * DataSizeUnit.Megabyte`,
    /// or 4MB.
    @objc
    optional func maxThumbnailFileSize(forFileExplorer explorer: FileExplorer) -> Double
    
    /// Specifies the edit actions that should display for an item in the table
    /// view of a explorer for a specific index path.
    /// - parameter explorer: to provide edit actions.
    /// - returns: The text to display when the user tries to delete a file.
    /// Default value should be `Strings.delete`.
    @objc
    optional func explorer(_ explorer: FileExplorer, editActionsFor tableView: UITableView?, indexPath: IndexPath?) -> [UITableViewRowAction]
    
    /// Returns the alternate view controller in which to display the next
    /// pushed explorer view controller.
    /// - parameter explorer: to provide an alternate view controller for.
    /// - returns: the alternate view controller in which to display the next
    /// view controller, or `nil` if the next view controller should be pushed
    /// onto the view controller stack.
    @objc
    optional func alternateViewController(forFileExplorer explorer: FileExplorer) -> UIViewController?
    
    /// Returns a unique section key for a given explorer and document.
    /// - parameter explorer: to provide a section titles.
    /// - parameter document: to provide a section title for.
    /// - returns: a unique key for the specified explorer and document.
    @objc
    optional func explorer(_ explorer: FileExplorer, sectionKeyFor document: Document) -> String?
    
    /// Returns a section title for a given explorer and document.
    /// - parameter explorer: to provide a section titles.
    /// - parameter document: to provide a section title for.
    /// - returns: a title for the specified explorer and document.
    @objc
    optional func explorer(_ explorer: FileExplorer, sectionTitleFor document: Document) -> String?
    
    /// Returns a section index title for a given explorer and document.
    /// - parameter explorer: to provide a section index titles.
    /// - parameter document: to provide a section index title for.
    /// - returns: an index title for the specified explorer and document.
    @objc
    optional func explorer(_ explorer: FileExplorer, sectionIndexTitleFor document: Document) -> String?
    
    // MARK: - Touch Event Handling Methods
    
    /// Called when the user selects a single table view cell.
    /// - parameter explorer: that spawned this event.
    /// - parameter cell: that was selected.
    /// - parameter tableView: of `explorer`.
    /// - parameter document: associated with `cell`.
    @objc
    optional func explorer(_ explorer: FileExplorer, didSelect cell: FileExplorerTableViewCell, from tableView: UITableView, with document: Document)
    
    /// Called when the user deselects a single table view cell.
    /// - parameter explorer: that spawned this event.
    /// - parameter cell: that was deselected.
    /// - parameter tableView: of `explorer`.
    /// - parameter document: associated with `cell`.
    @objc
    optional func explorer(_ explorer: FileExplorer, didDeselect cell: FileExplorerTableViewCell, from tableView: UITableView, with document: Document)
    
    /// Called when the user presses and holds a table view cell.
    /// - parameter explorer: that spawned this event.
    /// - parameter cell: that was long pressed.
    /// - parameter tableView: of `explorer`.
    /// - parameter document: associated with `cell`.
    @objc
    optional func explorer(_ explorer: FileExplorer, didSelectAndHold cell: FileExplorerTableViewCell, from tableView: UITableView, with document: Document)
    
    /// Called when the accessory button of a table view cell is tapped
    /// by the user.
    /// - parameter explorer: that spawned this event.
    /// - parameter barButtonItem: that was pressed.
    /// - parameter cell: containing `barButtonItem`.
    /// - parameter tableView: of `explorer`.
    /// - parameter document: associated with `cell`.
    @objc
    optional func explorer(_ explorer: FileExplorer, didPress barButtonItem: UIBarButtonItem, in cell: FileExplorerTableViewCell, from tableView: UITableView, with document: Document)
    
    // MARK: - Event Handling Methods
    
    /// Called before loading the contents of the current directory.
    @objc
    optional func explorerWillLoad(_ explorer: FileExplorer)
    
    /// Called after loading the contents of the current directory.
    @objc
    optional func explorerDidLoad(_ explorer: FileExplorer)
    
    /// Called when a explorer will resign.
    @objc
    optional func explorerWillResign(_ explorer: FileExplorer)
    
    /// Called when a explorer did resign.
    @objc
    optional func explorerDidResign(_ explorer: FileExplorer)
    
    /// Called when the user changes the editing mode of a explorer instance.
    /// - parameter explorer: The explorer that spawned this event.
    @objc
    optional func explorerDidChangeEditingMode(_ explorer: FileExplorer)
    
    // MARK: - Document Handling Methods
    
    /// Called when the user attempts to create a document.
    /// - parameter explorer: that spawned this event.
    /// - parameter document: the user is attempting to create.
    /// - parameter completionHandler: to execute after the delegate has
    /// completed the task.
    func explorer(_ explorer: FileExplorer, shouldCreate document: Document, completionHandler: ((Bool) -> ())?)
    
    /// Called when the user attempts to delete documents.
    /// - parameter explorer: that spawned this event.
    /// - parameter documents: the user is attempting to delete.
    /// - parameter completionHandler: to execute after the delegate has
    /// completed the task.
    func explorer(_ explorer: FileExplorer, shouldDelete documents: [Document], completionHandler: ((Bool) -> ())?)
    
    /// Called when the user attempts to open a document.
    /// - parameter explorer: that spawned this event.
    /// - parameter document: the user is attempting to open.
    /// - parameter completionHandler: to execute after the delegate has
    /// completed the task.
    func explorer(_ explorer: FileExplorer, shouldOpen document: Document, completionHandler: ((Bool) -> ())?)
    
    /// Called when the user attempts to close a document.
    /// - parameter explorer: that spawned this event.
    /// - parameter document: the user is attempting to close.
    /// - parameter completionHandler: to execute after the delegate has
    /// completed the task.
    func explorer(_ explorer: FileExplorer, shouldClose document: Document, completionHandler: ((Bool) -> ())?)
    
}

/// Provides a view controller implementation that allows for the browsing,
/// modification, and selection of files, directories, and/or symbolic links 
/// using an intuitive table view display.
@objc(FileExplorer)
open class FileExplorer: UIViewController {
    
    /// Data structure for a Section in a explorer table view.
    public class Section: Comparable {
        
        /// Resource category of this section. Default is `.regularFile`.
        public let resourceCategory: URLFileResourceType
        
        /// Key used for sorting collections of section instances.
        public let key: String
        
        /// Title of this section.
        public let title: String
        
        /// Index title of this section.
        public let indexTitle: String
        
        /// Documents for this section.
        public var documents: [Document]
        
        /// Constructs a new section instance with a specified title, index,
        /// and set of documents.
        /// - parameter category: of this section.
        /// - parameter key: of this section.
        /// - parameter title: of this section.
        /// - parameter indexTitle: of this section.
        /// - parameter documents: of this section.
        public init(resourceCategory: URLFileResourceType = .regular,
                    key: String, title: String? = nil, indexTitle: String? = nil, documents: [Document] = []) {
            self.resourceCategory = resourceCategory
            self.key = key
            self.title = title ?? key
            self.indexTitle = indexTitle ?? key
            self.documents = documents
        }
        
        public static func < (lhs: Section, rhs: Section) -> Bool {
            return (lhs.resourceCategory == .directory && rhs.resourceCategory == .regular) ||
                (lhs.resourceCategory == rhs.resourceCategory && lhs.key <= rhs.key)
        }
        
        public static func == (lhs: Section, rhs: Section) -> Bool {
            return lhs.resourceCategory == rhs.resourceCategory && lhs.key == rhs.key
        }
        
        /// Adds a document to this section.
        /// - parameter document: to add to this section.
        /// - parameter autoSort: specify `true` if `sort()` should be called
        /// immediately after executing this operation. Default is `false`.
        public func add(document: Document, autoSort: Bool = false) {
            documents.append(document)
            if autoSort { sort() }
        }
        
        /// Inserts a document to this section at a specified index.
        /// - parameter document: to add to this section.
        /// - parameter index: at which to insert the document.
        /// - parameter autoSort: specify `true` if `sort()` should be called
        /// immediately after executing this operation. Default is `false`.
        public func insert(document: Document, at index: Int, autoSort: Bool = false) {
            documents.insert(document, at: index)
            if autoSort { sort() }
        }
        
        /// Removes all instances of a document from this section.
        /// - parameter document: to remove from this section.
        /// - parameter autoSort: specify `true` if `sort()` should be called
        /// immediately after executing this operation. Default is `false`.
        public func remove(document: Document, autoSort: Bool = false) {
            documents.removeAll { $0.fileURL == document.fileURL }
            if autoSort { sort() }
        }
        
        /// Removes a document at a specified index.
        /// - parameter index: of the document to remove.
        /// - parameter autoSort: specify `true` if `sort()` should be called
        /// immediately after executing this operation. Default is `false`.
        @discardableResult
        public func remove(at index: Int, autoSort: Bool = false) -> Document {
            let document = documents.remove(at: index)
            if autoSort { sort() }
            return document
        }
        
        /// Sorts the documents of this section alphabetically.
        public func sort() {
            documents.sort { $0.filename < $1.filename }
        }
        
    }
    
    /// Enumerated type for different explorer layout styles.
    public enum LayoutStyle {
        
        /// Default style that uses a navigation controller with a view
        /// controller stack for each directory level.
        case normal
        
        /// Style that allows for directories to display their contents within
        /// the same table view as a cascading tree (uses more memory and
        /// computing power).
        case cascading
        
    }
    
    // MARK: - Static Properties
    
    ///
    public static var resourceKeys: [URLResourceKey] = {
        var keys = [URLResourceKey]()
        keys.append(.nameKey)
        keys.append(.localizedNameKey)
        keys.append(.isRegularFileKey)
        keys.append(.isDirectoryKey)
        keys.append(.isSymbolicLinkKey)
        //keys.append(.isVolumeKey)
        //keys.append(.isPackageKey)
        //keys.append(.isApplicationKey)
        //keys.append(.isSystemImmutableKey)
        //keys.append(.isUserImmutableKey)
        keys.append(.isHiddenKey)
        //keys.append(.hasHiddenExtensionKey)
        keys.append(.creationDateKey)
        keys.append(.contentAccessDateKey)
        keys.append(.contentModificationDateKey)
        keys.append(.attributeModificationDateKey)
        //keys.append(.linkCountKey)
        //keys.append(.parentDirectoryURLKey)
        //keys.append(.volumeURLKey)
        keys.append(.typeIdentifierKey)
        keys.append(.localizedTypeDescriptionKey)
        //keys.append(.labelNumberKey)
        //keys.append(.labelColorKey)
        //keys.append(.localizedLabelKey)
        //keys.append(.effectiveIconKey)
        //keys.append(.customIconKey)
        keys.append(.fileResourceIdentifierKey)
        //keys.append(.volumeIdentifierKey)
        //keys.append(.preferredIOBlockSizeKey)
        //keys.append(.isReadableKey)
        //keys.append(.isWritableKey)
        //keys.append(.isExecutableKey)
        keys.append(.fileSecurityKey)
        //keys.append(.isExcludedFromBackupKey)
        //keys.append(.pathKey)
        //keys.append(.canonicalPathKey)
        //keys.append(.isMountTriggerKey)
        //keys.append(.generationIdentifierKey)
        //keys.append(.documentIdentifierKey)
        //keys.append(.addedToDirectoryDateKey)
        keys.append(.fileResourceTypeKey)
        //keys.append(.thumbnailDictionaryKey)
        keys.append(.fileSizeKey)
        //keys.append(.fileAllocatedSizeKey)
        keys.append(.totalFileSizeKey)
        //keys.append(.totalFileAllocatedSizeKey)
        //keys.append(.isAliasFileKey)
        //keys.append(.fileProtectionKey)
        //keys.append(.volumeLocalizedFormatDescriptionKey)
        //keys.append(.volumeTotalCapacityKey)
        //keys.append(.volumeAvailableCapacityKey)
        //keys.append(.volumeResourceCountKey)
        //keys.append(.volumeSupportsPersistentIDsKey)
        //keys.append(.volumeSupportsSymbolicLinksKey)
        //keys.append(.volumeSupportsHardLinksKey)
        //keys.append(.volumeSupportsJournalingKey)
        //keys.append(.volumeIsJournalingKey)
        //keys.append(.volumeSupportsSparseFilesKey)
        //keys.append(.volumeSupportsZeroRunsKey)
        //keys.append(.volumeSupportsCaseSensitiveNamesKey)
        //keys.append(.volumeSupportsCasePreservedNamesKey)
        //keys.append(.volumeSupportsRootDirectoryDatesKey)
        //keys.append(.volumeSupportsVolumeSizesKey)
        //keys.append(.volumeSupportsRenamingKey)
        //keys.append(.volumeSupportsAdvisoryFileLockingKey)
        //keys.append(.volumeSupportsExtendedSecurityKey)
        //keys.append(.volumeIsBrowsableKey)
        //keys.append(.volumeMaximumFileSizeKey)
        //keys.append(.volumeIsEjectableKey)
        //keys.append(.volumeIsRemovableKey)
        //keys.append(.volumeIsInternalKey)
        //keys.append(.volumeIsAutomountedKey)
        //keys.append(.volumeIsLocalKey)
        //keys.append(.volumeIsReadOnlyKey)
        //keys.append(.volumeCreationDateKey)
        //keys.append(.volumeURLForRemountingKey)
        //keys.append(.volumeUUIDStringKey)
        //keys.append(.volumeNameKey)
        //keys.append(.volumeLocalizedNameKey)
        //keys.append(.volumeIsEncryptedKey)
        //keys.append(.volumeIsRootFileSystemKey)
        //keys.append(.volumeSupportsCompressionKey)
        //keys.append(.volumeSupportsFileCloningKey)
        //keys.append(.volumeSupportsSwapRenamingKey)
        //keys.append(.volumeSupportsExclusiveRenamingKey)
        //keys.append(.volumeSupportsImmutableFilesKey)
        //keys.append(.volumeSupportsAccessPermissionsKey)
        //keys.append(.volumeAvailableCapacityForImportantUsageKey)
        //keys.append(.volumeAvailableCapacityForOpportunisticUsageKey)
        keys.append(.isUbiquitousItemKey)
        keys.append(.ubiquitousItemHasUnresolvedConflictsKey)
        keys.append(.ubiquitousItemIsDownloadingKey)
        keys.append(.ubiquitousItemIsUploadedKey)
        keys.append(.ubiquitousItemIsUploadingKey)
        keys.append(.ubiquitousItemDownloadingStatusKey)
        keys.append(.ubiquitousItemDownloadingErrorKey)
        keys.append(.ubiquitousItemUploadingErrorKey)
        keys.append(.ubiquitousItemDownloadRequestedKey)
        keys.append(.ubiquitousItemContainerDisplayNameKey)
        if #available(iOS 10.0, *) {
            keys.append(.ubiquitousItemIsSharedKey)
            keys.append(.ubiquitousSharedItemCurrentUserRoleKey)
            keys.append(.ubiquitousSharedItemCurrentUserPermissionsKey)
            keys.append(.ubiquitousSharedItemOwnerNameComponentsKey)
            keys.append(.ubiquitousSharedItemMostRecentEditorNameComponentsKey)
        }
        return keys
    }()

    // MARK: - Instance Properties
    
    override open var title: String? {
        didSet {
            titleLabel.text = title
            guard let superview = titleLabel.superview else { return }
            let newSize = pathComponents.count > 0 ? 0.7 : 1.0
            titleLabel.snp.updateConstraints({ (dims) in
                dims.height.equalTo(superview).multipliedBy(newSize)
            })
        }
    }
    
    /// Subtitle of this title label.
    open var subtitle: String = "" {
        didSet {
            subtitleLabel.text = subtitle
            guard let superview = titleLabel.superview else { return }
            let newSize = pathComponents.count > 0 ? 0.3 : 0.0
            subtitleLabel.snp.updateConstraints({ (dims) in
                dims.height.equalTo(superview).multipliedBy(newSize)
            })
        }
    }
    
    /// Delegate object that responds to events spawned by `FileExplorer`
    /// instances.
    open weak var delegate: FileExplorerDelegate?
    
    /// Parent explorer linked to this one, if `layout` is set to `normal`,
    /// and this explorer has a preceding explorer parent directory.
    open weak var parentDirectoryFileExplorer: FileExplorer?
    
    /// URL of the directory whose contents are to be displayed.
    open var directoryURL: URL? { didSet { loadFilesystem() } }
    
    /// Path components of this explorer.
    open lazy var pathComponents = [String]()
    
    /// Surjective mapping between a set of section header names and a set
    /// of `Document` objects sorted alphabetically by filename.
    /// Directory sections will appear before regular file sections.
    open var sectionMap = [String: Section]() {
        didSet {
            sections = sectionMap.map { $1 }.sorted()
            sectionTitles = sections.map { $0.title }
            sectionIndexTitles = sections.map { $0.indexTitle }
        }
    }
    
    /// Returns the set of section header names of the current dirrctory,
    /// sorted alphabetically.
    open fileprivate (set) lazy var sections: [Section] = {
        return sectionMap.map { $1 }.sorted()
    }()
    
    /// Returns the set of section header names of the current directory,
    /// sorted alphabetically.
    open fileprivate (set) lazy var sectionTitles: [String] = {
        return sections.map { $0.title }
    }()
    
    /// Returns the set of section header names of the current directory,
    /// sorted alphabetically.
    open fileprivate (set) lazy var sectionIndexTitles: [String] = {
        return sections.map { $0.indexTitle }
    }()
    
    /// Scope used for deciding what types of files to make visible.
    /// Default value is `.default`.
    open var scope: URLFileResourceType.Mask = .default { didSet { loadFilesystem() } }
    
    /// Indicates the max image file size allowed for generating thumbnails.
    /// Default value is 2MB (2000 * 1024).
    open lazy var maxThumbnailFileSize: Double = {
        return delegate?.maxThumbnailFileSize?(forFileExplorer: self) ?? DataSizeUnit.Megabyte * 4 // = 4MB
    }()
    
    /// Layout of this explorer.
    open var layoutStyle: LayoutStyle = .normal {
        didSet { }
    }
    
    /// Style used when displaying the table view. Default style is
    /// `.grouped`.
    open var tableStyle: UITableView.Style = .plain {
        didSet {
            tableView.removeFromSuperview()
            tableView = autogeneratedTableView
            view.addSubview(tableView)
            tableView.snp.makeConstraints { (dims) in
                dims.top.equalTo(view)
                dims.left.equalTo(view)
                dims.bottom.equalTo(view)
                dims.right.equalTo(view)
            }
            loadFilesystem()
        }
    }
    
    /// The number of table rows at which to display the index list on the right edge of the table.
    open var sectionIndexMinimumDisplayRowCount: Int = 30 {
        didSet { tableView.sectionIndexMinimumDisplayRowCount = sectionIndexMinimumDisplayRowCount }
    }
    
    /// FileExplorer.Theme used when displaying the table view.
    open lazy var theme: FileExplorer.Theme? = { return delegate?.theme?(forFileExplorer: self) ?? .default }()
    
    /// Selected documents.
    open var selectedDocuments: [Document] {
        var documents = [Document]()
        for indexPath in tableView.indexPathsForSelectedRows ?? [] {
            documents.append(documentAt(indexPath))
        }
        return documents
    }
    
    /// Title view of this explorer
    fileprivate lazy var titleView: UIView = {
        let view = UIView()
        let stackView = UIStackView()
        stackView.axis = .vertical
        stackView.addArrangedSubview(titleLabel)
        stackView.addArrangedSubview(subtitleLabel)
        view.addSubview(stackView)
        stackView.constrainToSuperview()
        return view
    }()
    
    /// Title label of the title view of this explorer.
    fileprivate lazy var titleLabel: UILabel = {
        let label = UILabel()
        label.textAlignment = .center
        label.font = .systemFont(ofSize: UIFont.systemFontSize)
        label.textColor = theme?.feature(named: .NavigationHeaderTitle)?.textColor
        label.lineBreakMode = .byTruncatingMiddle
        return label
    }()
    
    /// Subtitle label of the title view of this explorer.
    fileprivate lazy var subtitleLabel: UILabel = {
        let label = UILabel()
        label.textAlignment = .center
        label.font = .systemFont(ofSize: UIFont.systemFontSize * 0.75)
        label.textColor = theme?.feature(named: .NavigationHeaderSubtitle)?.textColor
        label.lineBreakMode = .byTruncatingMiddle
        return label
    }()
    
    /// Status bar view of this explorer.
    fileprivate lazy var statusBarView: UIView = {
        let view = UIView()
        view.backgroundColor = UIColor(0xAAAAAA)
        let stackView = UIStackView()
        stackView.addArrangedSubview(statusBarLabel)
        view.addSubview(stackView)
        stackView.constrainToSuperview()
        view.snp.makeConstraints({ (dims) in
            dims.height.equalTo(25.0)
        })
        return view
    }()
    
    /// Status bar label of this explorer.
    fileprivate lazy var statusBarLabel: UILabel = {
        let label = UILabel()
        label.lineBreakMode = .byTruncatingMiddle
        return label
    }()
    
    /// Table view that will display the contents of the current directory.
    fileprivate lazy var tableView: UITableView = autogeneratedTableView
    
    /// Creates a new table view intialized with `tableStyle`.
    fileprivate var autogeneratedTableView: UITableView {
        
        let tableView = UITableView(frame: .zero, style: tableStyle)
        
        tableView.delegate = self
        tableView.dataSource = self
        
        tableView.allowsMultipleSelection = false
        tableView.allowsMultipleSelectionDuringEditing = true
        tableView.sectionIndexMinimumDisplayRowCount = sectionIndexMinimumDisplayRowCount
        
        if #available(iOS 9.0, *) {
            tableView.cellLayoutMarginsFollowReadableWidth = false
        }
        
        tableView.register(
            FileExplorerTableViewCell.self,
            forCellReuseIdentifier: String(FileExplorerTableViewCell.hash()))
        
        return tableView
        
    }
    
    /// Search controller that will appear as the table view header.
    fileprivate lazy var searchController: UISearchController = {
        let searchController = UISearchController(searchResultsController: nil)
        let searchBar = searchController.searchBar
        searchBar.scopeButtonTitles = ["Local", "Hierarchical"]
        return searchController
    }()
    
    // MARK: - Constructor Methods
    
    /// Contructs a new explorer using a particular table view style.
    /// - parameter directoryURL: URL of the directory to browse (Optional).
    /// - parameter style: Table style to use when displaying the table view.
    /// (Optional; Default value is `.grouped`).
    /// - parameter delegate: Delegating object (Optional).
    public convenience init(directoryURL: URL, style: UITableView.Style = .grouped) {
        self.init(nibName: nil, bundle: nil)
        self.directoryURL = directoryURL
        tableStyle = style
    }
    
    // MARK: - UIViewController Methods
    
    override open func viewDidLoad() {
        
        super.viewDidLoad()
        
        edgesForExtendedLayout = UIRectEdge()
        
        navigationController?.isNavigationBarHidden = false
        navigationController?.isToolbarHidden = false
        
        navigationItem.titleView = titleView
        
        let stackView = UIStackView()
        stackView.axis = .vertical
        stackView.addArrangedSubview(statusBarView)
        stackView.addArrangedSubview(tableView)
        
        view.addSubview(stackView)
        stackView.constrainToSuperview()
        
    }
    
    override open func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        loadFilesystem()
        updateToolbarItems()
    }
    
    override open func willMove(toParentViewController parent: UIViewController?) {
        super.willMove(toParentViewController: parent)
        if parent == nil {
            delegate?.explorerWillResign?(self)
        }
    }
    
    override open func didMove(toParentViewController parent: UIViewController?) {
        super.didMove(toParentViewController: parent)
        if parent == nil {
            delegate?.explorerDidResign?(self)
        }
    }
    
    override open func setEditing(_ editing: Bool, animated: Bool) {
        super.setEditing(editing, animated: animated)
        tableView.setEditing(editing, animated: animated)
        delegate?.explorerDidChangeEditingMode?(self)
    }
    
}

// MARK: - UITableViewDataSource Methods
extension FileExplorer: UITableViewDataSource {
    
    open func numberOfSections(in tableView: UITableView) -> Int {
        return sections.count
    }
    
    open func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return sections[section].documents.count
    }
    
    open func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let _cell = tableView.dequeueReusableCell(withIdentifier: String(FileExplorerTableViewCell.hash()),
                                                  for: indexPath)
        
        guard let cell = _cell as? FileExplorerTableViewCell else { return _cell }
        
        let docref = documentAt(indexPath)
        
        cell.delegate = self
        cell.titleColor = .black
        
        var document = docref
        if docref.isSymbolicLink {
            document = docref.underlyingResource
            cell.titleColor = .blue
        }
        
        if document.isInferredHidden || document.isHidden {
            cell.titleColor = .lightGray
        }
        
        cell.title = document.displayName
        
        switch document.underlyingResource.resourceType {
            
        case .directory:
            cell.accessoryType = .detailDisclosureButton
            cell.iconImage = theme?.thumbnail(for: .directory)
            cell.subtitle = "file".localized(with: document.fileCount)
            break
            
        case .regular:
            cell.accessoryType = .detailButton
            cell.iconImage = document.thumbnail(with: CGSize(width: 40.0, height: 40.0)) ?? theme?.thumbnail(for: document)
            cell.subtitle = document.fileSize.formattedDataSize()
            let formatter = DateFormatter()
            formatter.dateStyle = .short
            formatter.timeStyle = .short
            formatter.locale = .current
            cell.subsubtitle = formatter.string(from: document.modificationDate)
            break
            
        default:
            break
            
        }
        
        return cell
        
    }
    
    open func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let fileCount = sections[section].documents.count
        let view = UIView()
        view.backgroundColor = theme?.feature(named: .SectionHeader)?.backgroundColor ?? UIColor(0xEEEEEE)
        let label = UILabel()
        label.lineBreakMode = .byTruncatingMiddle
        label.text = String(format: "%@ (%@)", sectionTitles[section], "item".localized(with: fileCount))
        label.font = .boldSystemFont(ofSize: UIFont.systemFontSize)
        label.textColor = theme?.feature(named: .SectionHeader)?.textColor ?? UIColor(0x444444)
        view.addSubview(label)
        label.snp.makeConstraints { (dims) in
            dims.top.equalTo(view)
            dims.left.equalTo(view).offset(10.0)
            dims.bottom.equalTo(view)
            dims.right.equalTo(view).offset(-10.0)
        }
        return view
    }
    
    open func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 20.0
    }
    
    open func tableView(_ tableView: UITableView, estimatedHeightForHeaderInSection section: Int) -> CGFloat {
        return 20.0
    }
    
    open func sectionIndexTitles(for tableView: UITableView) -> [String]? {
        return sectionIndexTitles
    }
    
    open func tableView(_ tableView: UITableView, sectionForSectionIndexTitle title: String, at index: Int) -> Int {
        return sectionIndexTitles.index(of: title) ?? NSNotFound
    }
    
    open func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        return false
    }
    
    open func tableView(_ tableView: UITableView, editActionsForRowAt indexPath: IndexPath) -> [UITableViewRowAction]? {
        if let editActions = delegate?.explorer?(self, editActionsFor: tableView, indexPath: indexPath) {  return editActions }
        var editActions = [UITableViewRowAction]()
        editActions.append(UITableViewRowAction(style: .destructive, title: "Delete") { (_, indexPath) in
            self.deleteDocuments(at: [indexPath])
        })
        return editActions
    }
    
    open func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        
        switch editingStyle {
            
        case .delete:
            delegate?.explorer(self, shouldDelete: [self.documentAt(indexPath)]) { _ = $0 }
            break
            
        case .insert:
            break
            
        default:
            break
            
        }
        
    }
    
    open func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 45.0
    }
    
}

// MARK: - UITableViewDelegate Methods
extension FileExplorer: UITableViewDelegate {
    
    open func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        guard let cell = tableView.cellForRow(at: indexPath) as? FileExplorerTableViewCell else { return }
        let document = documentAt(indexPath)
        delegate?.explorer?(self, didSelect: cell, from: tableView, with: document)
        open(document: document)
    }
    
    open func tableView(_ tableView: UITableView, didDeselectRowAt indexPath: IndexPath) {
        guard let cell = tableView.cellForRow(at: indexPath) as? FileExplorerTableViewCell else { return }
        let document = documentAt(indexPath)
        delegate?.explorer?(self, didDeselect: cell, from: tableView, with: document)
    }
    
    open func tableView(_ tableView: UITableView, accessoryButtonTappedForRowWith indexPath: IndexPath) {
        guard let cell = tableView.cellForRow(at: indexPath) as? FileExplorerTableViewCell else { return }
        let document = documentAt(indexPath)
        delegate?.explorer?(self, didPress: cell.barButtonItem, in: cell, from: tableView, with: document)
    }
    
}

// MARK: - UISearchBarDelegate Methods
extension FileExplorer: UISearchBarDelegate {
    
}

// MARK: - UISearchControllerDelegate Methods
extension FileExplorer: UISearchControllerDelegate {
    
    ///
    open func updateSearchResults(for searchController: UISearchController) {
        
    }
    
}

// MARK: - UISearchResultsUpdating Methods
extension FileExplorer: UISearchResultsUpdating {
    
}

// MARK: - UIAlertViewDelegate Methods
extension FileExplorer: UIAlertViewDelegate {
    
}

// MARK: - FileExplorerTableViewCellDelegate Methods
extension FileExplorer: FileExplorerTableViewCellDelegate {
    
    public func didRecognize(longPressGesture: UILongPressGestureRecognizer, in cell: FileExplorerTableViewCell) {
        guard longPressGesture.state == .began, let indexPath = tableView.indexPath(for: cell) else { return }
        let document = documentAt(indexPath)
        delegate?.explorer?(self, didSelectAndHold: cell, from: tableView, with: document)
    }
    
}

// MARK: - Instance Methods
extension FileExplorer {
    
    /// Default section index value for a document.
    /// - parameter document: to generate a section index for.
    open func sectionKey(for document: Document) -> String  {
        return (document.underlyingResource.isDirectory ? "📁 " : "") + document.filename.firstLetter.uppercased()
    }
    
    /// Returns the section for the given document.
    open func section(for document: Document) -> Section? {
        let sectionKey = delegate?.explorer?(self, sectionKeyFor: document) ?? self.sectionKey(for: document)
        return sectionMap[sectionKey]
    }
    
    /// Returns the documents contained in a particular section.
    /// - parameter section: Index of the section whose documents are to be
    /// returned.
    /// - returns: The documents contained in the section located specified
    /// index or an empty collections if no such section exists.
    open func documentsIn(_ section: Int) -> [Document] {
        return sections[section].documents
    }
    
    /// Returns the document located at a given index path.
    /// - parameter indexPath: Index path of the document to return.
    /// - returns: The document located at `indexPath` or `nil` if no such
    /// document exists.
    open func documentAt(_ indexPath: IndexPath) -> Document {
        return documentsIn(indexPath.section)[indexPath.row]
    }
    
    open func documentsAt(_ indexPaths: [IndexPath]) -> [Document] {
        return indexPaths.map { self.documentAt($0) }
    }
    
    /// Updates the filesystem and reloads the table view display.
    open func loadFilesystem() {
        
        guard let directoryURL = directoryURL else {
            pathComponents = []
            return
        }
        
        pathComponents = parentDirectoryFileExplorer?.pathComponents ?? []
        if let parentDirectoryURL = parentDirectoryFileExplorer?.directoryURL {
            pathComponents.append(parentDirectoryURL.lastPathComponent)
        }
        
        title = directoryURL.lastPathComponent
        subtitle = pathComponents.joined(separator: " ➤ ")
        
        let workingDirectory = Document(fileURL: directoryURL)
        guard workingDirectory.isDirectory else {
            print(String(format: "Supplied directory URL \"%@\" is not a directory. %@",
                         directoryURL.absoluteString,
                         "Unable to load filesystem contents as a result."))
            return
        }
        
        delegate?.explorerWillLoad?(self)
        
        var sectionMap = [String: Section]()
        
        let fileURLs: [URL] = (try? FileManager.default.contentsOfDirectory(at: directoryURL,
                                                                            includingPropertiesForKeys: [],
                                                                            options: [])) ?? []
        for fileURL in fileURLs {
            
            let document = Document(fileURL: fileURL)
            if !scope.contains(.hidden) && (document.isInferredHidden || document.isHidden) { continue }
            guard (scope.contains(.directory) && document.underlyingResource.isDirectory) ||
                (scope.contains(.regular) && document.underlyingResource.isRegularFile) else { continue }
            let key = delegate?.explorer?(self, sectionKeyFor: document) ?? sectionKey(for: document)
            let title = delegate?.explorer?(self, sectionTitleFor: document)
            let indexTitle = delegate?.explorer?(self, sectionIndexTitleFor: document)
            let section = sectionMap[key] ??
                Section(resourceCategory: document.underlyingResource.resourceType,
                        key: key, title: title, indexTitle: indexTitle)
            section.add(document: document)
            sectionMap[key] = section
            
        }
        
        self.sectionMap = sectionMap
        tableView.reloadData()
        
        delegate?.explorerDidLoad?(self)
        
    }
    
    /// Opens a document.
    open func open(document: Document) {
        
        switch document.underlyingResource.resourceType {
            
        case .directory:
            let newFileExplorer = FileExplorer(directoryURL: document.fileURL)
            newFileExplorer.delegate = delegate
            newFileExplorer.parentDirectoryFileExplorer = self
            if let alternateViewController = delegate?.alternateViewController?(forFileExplorer: self) {
                alternateViewController.show(newFileExplorer, sender: true)
            } else {
                navigationController?.pushViewController(newFileExplorer, animated: true)
            }
            break
            
        case .regular:
            delegate?.explorer(self, shouldOpen: document) { _ = $0  }
            break
            
        default:
            break
            
        }
        
    }
    
    ///
    open func close(document: Document) {
        delegate?.explorer(self, shouldClose: document) { _ = $0 }
    }
    
    /// Updates the toolbar items of this explorer.
    open func updateToolbarItems(animated: Bool = false) {
        setToolbarItems(delegate?.toolbarItems?(forFileExplorer: self), animated: animated)
    }
    
    /// This method is called whenever the user tries to create a new document.
    /// The delegate is responsible for creating document resources and
    /// returning control to the explorer afterwards.
    /// - parameter document: Document that was inserted.
    /// - parameter indexPath: IndexPath to insert the document at.
    open func insert(_ document: Document, at indexPath: IndexPath) {
        delegate?.explorer(self, shouldCreate: document) {
            if $0 {
                self.sections[indexPath.section].insert(document: document, at: indexPath.row)
                self.tableView.insertRows(at: [indexPath], with: .automatic)
            }
        }
    }
    
    /// This method is called whenever the user tries to delete a document.
    /// The delegate is responsible for deleting document resources and
    /// returning control to the explorer afterwards.
    /// - parameter indexPaths: of the documents to remove.
    open func deleteDocuments(at indexPaths: [IndexPath]) {
        let documents = indexPaths.map { self.documentAt($0) }
        delegate?.explorer(self, shouldDelete: documents) {
            if $0 {
                var removeSections = [Int]()
                var updateSections = [Int]()
                for indexPath in indexPaths {
                    let section = self.sections[indexPath.section]
                    section.remove(at: indexPath.row)
                    if section.documents.count < 1 {
                        self.sections.remove(at: indexPath.section)
                        self.sectionMap.removeValue(forKey: section.key)
                        removeSections.append(indexPath.section)
                    }
                    updateSections.append(indexPath.section)
                }
                var indexPaths = indexPaths
                indexPaths.removeAll { removeSections.contains($0.section) }
                updateSections.removeAll { removeSections.contains($0) }
                if removeSections.count > 0 {
                    self.tableView.deleteSections(IndexSet(removeSections), with: .automatic)
                }
                self.tableView.deleteRows(at: indexPaths, with: .automatic)
                self.tableView.reloadSections(IndexSet(updateSections), with: .automatic)
            }
        }
    }
    
    /// Selects all documents in the current directory.
    open func selectAll() {
        guard isEditing else { return }
        for i in 0 ..< sectionMap.count {
            let documents = documentsIn(i)
            for j in 0 ..< documents.count {
                tableView.selectRow(at: IndexPath(row: j, section: i), animated: true, scrollPosition: .none)
            }
        }
    }
    
    /// Deselects all documents in the current directory.
    open func deselectAll() {
        guard isEditing else { return }
        for i in 0 ..< sectionMap.count {
            let documents = documentsIn(i)
            for j in 0 ..< documents.count {
                tableView.deselectRow(at: IndexPath(row: j, section: i), animated: true)
            }
        }
    }
    
    /// Selects the inverse of the current selection in the current directory.
    open func invertSelection() {
        guard isEditing else { return }
        for i in 0 ..< sectionMap.count {
            let documents = documentsIn(i)
            for j in 0 ..< documents.count {
                let indexPath = IndexPath(row: j, section: i)
                guard let cell = tableView.cellForRow(at: indexPath) else { continue }
                cell.isSelected ?
                    tableView.deselectRow(at: indexPath, animated: true) :
                    tableView.selectRow(at: indexPath, animated: true, scrollPosition: .none)
            }
        }
    }
    
}
