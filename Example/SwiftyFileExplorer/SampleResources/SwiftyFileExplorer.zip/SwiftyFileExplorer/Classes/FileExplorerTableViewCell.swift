//
// The MIT License (MIT)
//
// Copyright © 2017 NoodleOfDeath. All rights reserved.
// NoodleOfDeath
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in
// all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
// THE SOFTWARE.

import UIKit
import Foundation

import SnapKit

/// Specifications for a `FileExplorerTableViewCell` delegate.
@objc(FileExplorerTableViewCellDelegate)
public protocol FileExplorerTableViewCellDelegate : class {
    
    /// Called when a table view cell is pressed and held by the user.
    func didRecognize(longPressGesture: UILongPressGestureRecognizer, in cell: FileExplorerTableViewCell)
    
}

/// Custom table view cell to be displayed by a explorer.
/// Usually displays file/directory name.
@objc(FileExplorerTableViewCell)
open class FileExplorerTableViewCell : UITableViewCell {

    // MARK: - Instance Properties
    
    /// Delegate explorer object.
    open weak var delegate: FileExplorerTableViewCellDelegate?
    
    /// Edge insets of this cell.
    open var edgeInsets = UIEdgeInsets(top: 10.0, left: 10.0, bottom: -10.0, right: -10.0)
    
    /// Main image of this cell.
    open var iconImage: UIImage? {
        get { return iconView.image }
        set { iconView.image = newValue }
    }
    
    /// Title of this cell.
    open var title: String! {
        get { return titleLabel.text }
        set { titleLabel.text = newValue }
    }
    
    /// Subtitle of this cell.
    /// Usually displays file size/file count.
    open var subtitle: String! {
        get { return subtitleLabel.text }
        set { subtitleLabel.text = newValue }
    }
    
    /// Subsubtitle of this cell.
    /// Usually displays the date modified.
    open var subsubtitle: String! {
        get { return subsubtitleLabel.text }
        set { subsubtitleLabel.text = newValue }
    }
    
    /// Displays the info accessory button
    open var displayInfoAccessory: Bool = false {
        didSet { setNeedsLayout() }
    }
    
    /// Color of the title label.
    open var titleColor: UIColor = .black {
        didSet { titleLabel.textColor = titleColor }
    }
    
    /// Bar button item view.
    open var barButtonItem: UIBarButtonItem {
        return UIBarButtonItem(customView: accessoryView ?? UIView())
    }
    
    fileprivate lazy var stackView: UIStackView = {
        let stackView = UIStackView()
        stackView.spacing = 10.0
        let gesture = UILongPressGestureRecognizer(target: self, action: #selector(didRecognize(longPressGesture:)))
        gesture.minimumPressDuration = 0.3
        stackView.addGestureRecognizer(gesture)
        return stackView
    }()
    
    /// Custom image view.
    fileprivate lazy var iconView: UIImageView = {
        let imageView = UIImageView()
        return imageView
    }()
    
    /// Center view of this cell.
    fileprivate lazy var mainContentView: UIView = {
        let view = UIStackView()
        view.axis = .vertical
        view.addArrangedSubview(titleView)
        view.addArrangedSubview(metaView)
        return view
    }()
    
    /// Title view of this cell.
    fileprivate lazy var titleView: UIView = {
        let view = UIView()
        view.addConstrainedSubview(titleLabel)
        return view
    }()
    
    /// Meta view of this cell.
    fileprivate lazy var metaView: UIView = {
        let view = UIStackView()
        view.spacing = 5.0
        view.addArrangedSubview(subtitleLabel)
        view.addArrangedSubview(subsubtitleLabel)
        return view
    }()
    
    /// Title label of this cell.
    fileprivate lazy var titleLabel: UILabel = {
        let label = UILabel()
        label.lineBreakMode = .byTruncatingMiddle
        return label
    }()
    
    /// Subtitle label of this cell.
    fileprivate lazy var subtitleLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: UIFont.systemFontSize * 0.75)
        return label
    }()
    
    /// Subsubtitle label of this cell.
    fileprivate lazy var subsubtitleLabel: UILabel = {
        let label = UILabel()
        label.textAlignment = .right
        label.font = .systemFont(ofSize: UIFont.systemFontSize * 0.75)
        return label
    }()
    
    // MARK: - UIView Methods
    
    override open func draw(_ rect: CGRect) {
        
        super.draw(rect)
        
        contentView.addSubview(stackView)
        stackView.snp.makeConstraints { (dims) in
            dims.top.equalTo(contentView)
            dims.left.equalTo(contentView).offset(15.0)
            dims.bottom.equalTo(contentView)
            dims.right.equalTo(contentView)
        }
        
        stackView.addArrangedSubview(iconView)
        iconView.snp.makeConstraints { (dims) in
            dims.width.equalTo(iconImage != nil ? 40.0 : 0.0)
        }
        
        stackView.addArrangedSubview(mainContentView)
        
    }
    
}

// MARK: - Event Handler Methods
extension FileExplorerTableViewCell {
    
    @objc
    /// Called when a long press gesture is recognized by this cell.
    /// - parameter longPressGesture: The long press gesture recognizer.
    fileprivate func didRecognize(longPressGesture: UILongPressGestureRecognizer) {
        delegate?.didRecognize(longPressGesture: longPressGesture, in: self)
    }
    
}
