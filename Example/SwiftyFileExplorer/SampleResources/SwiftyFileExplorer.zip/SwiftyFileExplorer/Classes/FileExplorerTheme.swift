//
// The MIT License (MIT)
//
// Copyright © 2017 NoodleOfDeath. All rights reserved.
// NoodleOfDeath
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in
// all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
// THE SOFTWARE.

import Foundation

import SwiftyFilesystem

extension FileExplorer {

    /// Specifications for a explorer theme.
    open class Theme: Bundle {
        
        /// Enumerated type representing the different features of a explorer
        /// theme.
        public class Feature {
            
            public enum Name: String {
                case NavigationHeaderTitle
                case NavigationHeaderSubtitle
                case NavigationToolbar
                case SectionHeader
            }
            
            public let font: UIFont
            public let backgroundColor: UIColor?
            public let textColor: UIColor
            
            public init?(dict: [String: Any]?) {
                guard let dict = dict else { return nil }
                font = .systemFont(ofSize: UIFont.systemFontSize)
                backgroundColor = nil
                textColor = .black
                if let _ = dict[NSAttributedStringKey.font.rawValue] as? [String: Any] {
                    
                }
                if let _ = dict[NSAttributedStringKey.foregroundColor.rawValue] as? [String: Any] {
                    
                }
                if let _ = dict[NSAttributedStringKey.backgroundColor.rawValue] as? [String: Any] {
                    
                }
            }
            
        }
        
        ///
        public struct k {
            public static let features = "SFFeatures"
        }
        
        // MARK: - Static Properties

        /// Default fallback theme singleton instance.
        open class var `default`: Theme? {
            guard
                let bundlePath = Bundle(for: FileExplorer.self).path(forResource: "SwiftyFileExplorer", ofType: "bundle"),
                let bundle = Bundle(path: bundlePath),
                let path = bundle.path(forResource: "default", ofType: "theme"),
                let theme = FileExplorer.Theme(path: path) else { return nil }
            return theme
        }
        
        // MARK: - Instance Properties
        
        /// Mapping of `URLFileResourceType` to image names.
        open var resourceTypeMap: [URLFileResourceType: String] {
            var map = [URLFileResourceType: String]()
            map[.regular] = "public.item"
            map[.directory] = "public.directory"
            return map
        }
        
        // MARK: - Features
        
        /// Features of this theme.
        open var features = [Feature.Name: Feature]()
        
        // MARK: - Thumbnails

        /// Default thumbnail used for any file.
        open var defaultThumbnail: UIImage? {
            return UIImage(named: "public.item", in: self, compatibleWith: nil)
        }
        
        // MARK: - Constructor Methods
        
        override public init?(path: String) {
            super.init(path: path)
            if let keyValues = infoDictionary?[k.features] as? [String: [String: Any]] {
                for (key, value) in keyValues {
                    guard let name = Feature.Name(rawValue: key) else { continue }
                    guard let feature = Feature(dict: value) else { continue }
                    features[name] = feature
                }
            }
        }
        
        // MARK: - Instance Methods

        /// Thumbnail used for a specific resource type.
        /// - parameter resourceType: to provide a thumbnail for.
        /// - returns: thumbnail associated with `resourceType`, or `nil` if
        /// no such association exists.
        open func thumbnail(for resourceType: URLFileResourceType) -> UIImage? {
            guard let name = resourceTypeMap[resourceType] else { return nil }
            return UIImage(named: name, in: self, compatibleWith: nil) ?? defaultThumbnail
        }

        /// Thumbnail used for a specific document.
        /// - parameter document: to provide a thumbnail for.
        /// - returns: thumbnail associated with `document`, or `nil` if
        /// no such association exists.
        open func thumbnail(for document: Document?) -> UIImage? {
            guard let uttype = document?.uttype else { return nil }
            return UIImage(named: uttype.rawValue, in: self, compatibleWith: nil) ?? defaultThumbnail
        }
        
        open func feature(named name: Feature.Name) -> Feature? {
            return features[name]
        }

    }

}

