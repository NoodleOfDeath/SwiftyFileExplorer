//
//  UIPaddedStackView.swift
//  SwiftyFileExplorer
//
//  Created by MORGAN, THOMAS B on 1/9/19.
//

import UIKit

import SnapKit

class UIPaddedStackView: UIStackView {
    
    override var axis: UILayoutConstraintAxis {
        didSet {
            if axis == .horizontal {
                paddedViewA.snp.updateConstraints { (dims) in
                    dims.width.equalTo(paddedViewB)
                }
            } else {
                paddedViewA.snp.updateConstraints { (dims) in
                    dims.width.equalTo(paddedViewB)
                }
            }
        }
    }
    
    fileprivate lazy var paddedViewA: UIStackView = {
        let stackView = UIStackView()
        return stackView
    }()
    
    fileprivate lazy var paddedViewB: UIStackView = {
        let stackView = UIStackView()
        return stackView
    }()
    
    override public init(frame: CGRect) {
        super.init(frame: frame)
        setup()
    }
    
    required init(coder: NSCoder) {
        super.init(coder: coder)
        setup()
    }
    
    override func addArrangedSubview(_ view: UIView) {
        super.insertArrangedSubview(view, at: arrangedSubviews.count)
    }
    
    fileprivate func setup() {
        addArrangedSubview(paddedViewA)
        addArrangedSubview(paddedViewB)
        paddedViewA.snp.makeConstraints { (dims) in
            dims.width.equalTo(paddedViewB)
        }
    }
    
}
